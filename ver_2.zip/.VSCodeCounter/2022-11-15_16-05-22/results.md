# Summary

Date : 2022-11-15 16:05:22

Directory d:\\Galad_ws\\YES_teknicSys\\ver_2\\src

Total : 10 files,  742 codes, 82 comments, 119 blanks, all 943 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C++ | 10 | 742 | 82 | 119 | 943 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 10 | 742 | 82 | 119 | 943 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)