# Details

Date : 2022-11-15 16:05:22

Directory d:\\Galad_ws\\YES_teknicSys\\ver_2\\src

Total : 10 files,  742 codes, 82 comments, 119 blanks, all 943 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [src/ArduinoBLENode.cpp](/src/ArduinoBLENode.cpp) | C++ | 43 | 5 | 8 | 56 |
| [src/CableController.cpp](/src/CableController.cpp) | C++ | 139 | 11 | 8 | 158 |
| [src/EndEffectorController.cpp](/src/EndEffectorController.cpp) | C++ | 0 | 0 | 1 | 1 |
| [src/GripperController.cpp](/src/GripperController.cpp) | C++ | 8 | 0 | 3 | 11 |
| [src/Main.cpp](/src/Main.cpp) | C++ | 112 | 12 | 20 | 144 |
| [src/RailController.cpp](/src/RailController.cpp) | C++ | 11 | 0 | 3 | 14 |
| [src/Robot.cpp](/src/Robot.cpp) | C++ | 240 | 39 | 46 | 325 |
| [src/TeknicNode.cpp](/src/TeknicNode.cpp) | C++ | 90 | 3 | 19 | 112 |
| [src/TrajectoryGenerator.cpp](/src/TrajectoryGenerator.cpp) | C++ | 70 | 6 | 8 | 84 |
| [src/TwincatADSNode.cpp](/src/TwincatADSNode.cpp) | C++ | 29 | 6 | 3 | 38 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)