# Diff Summary

Date : 2022-11-15 16:05:48

Directory d:\\Galad_ws\\YES_teknicSys\\ver_2

Total : 1399 files,  209079 codes, 58945 comments, 41000 blanks, all 309024 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C | 528 | 131,907 | 47,373 | 24,655 | 203,935 |
| C++ | 793 | 65,404 | 11,279 | 14,036 | 90,719 |
| CMake | 44 | 6,059 | 0 | 894 | 6,953 |
| CUDA C++ | 14 | 2,732 | 173 | 695 | 3,600 |
| Markdown | 2 | 1,311 | 0 | 454 | 1,765 |
| XML | 2 | 647 | 0 | 2 | 649 |
| Shell Script | 8 | 363 | 40 | 113 | 516 |
| CSS | 2 | 207 | 18 | 58 | 283 |
| JavaScript | 1 | 202 | 15 | 30 | 247 |
| Python | 3 | 178 | 47 | 62 | 287 |
| JSON | 1 | 60 | 0 | 0 | 60 |
| Properties | 1 | 9 | 0 | 1 | 10 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 1,399 | 209,079 | 58,945 | 41,000 | 309,024 |
| Dependencies | 1,388 | 192,876 | 55,003 | 38,280 | 286,159 |
| Dependencies\\DynamixelSDK-3.7.31 | 27 | 3,302 | 2,587 | 1,078 | 6,967 |
| Dependencies\\DynamixelSDK-3.7.31\\include | 13 | 569 | 2,215 | 413 | 3,197 |
| Dependencies\\DynamixelSDK-3.7.31\\include\\dynamixel_sdk | 13 | 569 | 2,215 | 413 | 3,197 |
| Dependencies\\DynamixelSDK-3.7.31\\src | 13 | 2,724 | 372 | 664 | 3,760 |
| Dependencies\\DynamixelSDK-3.7.31\\src\\dynamixel_sdk | 12 | 2,723 | 372 | 663 | 3,758 |
| Dependencies\\TcAdsDll | 4 | 982 | 146 | 194 | 1,322 |
| Dependencies\\TcAdsDll\\CE | 2 | 491 | 73 | 97 | 661 |
| Dependencies\\TcAdsDll\\CE\\Include | 2 | 491 | 73 | 97 | 661 |
| Dependencies\\TcAdsDll\\Include | 2 | 491 | 73 | 97 | 661 |
| Dependencies\\eigen-3.3.7 | 1,344 | 183,596 | 40,664 | 36,076 | 260,336 |
| Dependencies\\eigen-3.3.7\\Eigen | 272 | 79,459 | 21,729 | 13,779 | 114,967 |
| Dependencies\\eigen-3.3.7\\Eigen\\src | 272 | 79,459 | 21,729 | 13,779 | 114,967 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Cholesky | 3 | 795 | 358 | 164 | 1,317 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\CholmodSupport | 1 | 384 | 173 | 83 | 640 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core | 133 | 34,765 | 8,954 | 7,011 | 50,730 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\arch | 27 | 9,590 | 1,076 | 1,899 | 12,565 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\arch\\AVX | 4 | 1,173 | 160 | 249 | 1,582 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\arch\\AVX512 | 2 | 1,293 | 183 | 233 | 1,709 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\arch\\AltiVec | 3 | 1,416 | 122 | 278 | 1,816 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\arch\\CUDA | 6 | 2,036 | 135 | 372 | 2,543 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\arch\\Default | 2 | 32 | 33 | 15 | 80 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\arch\\NEON | 3 | 956 | 144 | 244 | 1,344 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\arch\\SSE | 4 | 1,512 | 207 | 290 | 2,009 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\arch\\ZVector | 3 | 1,172 | 92 | 218 | 1,482 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\functors | 6 | 1,209 | 379 | 202 | 1,790 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\products | 21 | 5,539 | 1,097 | 970 | 7,606 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Core\\util | 12 | 3,308 | 1,048 | 713 | 5,069 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Eigenvalues | 14 | 2,794 | 2,154 | 550 | 5,498 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Geometry | 15 | 3,121 | 1,597 | 724 | 5,442 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Geometry\\arch | 1 | 118 | 20 | 24 | 162 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Householder | 3 | 398 | 273 | 77 | 748 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\IterativeLinearSolvers | 8 | 1,402 | 575 | 318 | 2,295 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\Jacobi | 1 | 324 | 89 | 50 | 463 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\LU | 6 | 1,393 | 742 | 310 | 2,445 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\LU\\arch | 1 | 207 | 76 | 56 | 339 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\MetisSupport | 1 | 94 | 31 | 13 | 138 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\OrderingMethods | 3 | 1,520 | 583 | 345 | 2,448 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\PaStiXSupport | 1 | 440 | 151 | 88 | 679 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\PardisoSupport | 1 | 353 | 121 | 70 | 544 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\QR | 6 | 1,254 | 921 | 296 | 2,471 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\SPQRSupport | 1 | 217 | 69 | 28 | 314 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\SVD | 5 | 1,955 | 589 | 331 | 2,875 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\SparseCholesky | 2 | 586 | 192 | 112 | 890 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\SparseCore | 30 | 6,584 | 1,315 | 1,399 | 9,298 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\SparseLU | 17 | 1,950 | 1,057 | 406 | 3,413 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\SparseQR | 1 | 478 | 183 | 85 | 746 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\StlSupport | 4 | 331 | 68 | 52 | 451 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\SuperLUSupport | 1 | 752 | 117 | 159 | 1,028 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\UmfPackSupport | 1 | 339 | 80 | 88 | 507 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\misc | 7 | 16,224 | 103 | 796 | 17,123 |
| Dependencies\\eigen-3.3.7\\Eigen\\src\\plugins | 7 | 1,006 | 1,234 | 224 | 2,464 |
| Dependencies\\eigen-3.3.7\\bench | 159 | 13,523 | 2,992 | 3,707 | 20,222 |
| Dependencies\\eigen-3.3.7\\bench\\btl | 102 | 6,167 | 2,018 | 2,332 | 10,517 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\actions | 21 | 1,551 | 607 | 758 | 2,916 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\cmake | 12 | 353 | 0 | 100 | 453 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\data | 8 | 532 | 87 | 229 | 848 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\generic_bench | 21 | 1,153 | 527 | 462 | 2,142 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\generic_bench\\init | 3 | 67 | 69 | 22 | 158 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\generic_bench\\static | 3 | 82 | 66 | 58 | 206 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\generic_bench\\timers | 8 | 549 | 216 | 254 | 1,019 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\generic_bench\\utils | 4 | 139 | 81 | 73 | 293 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs | 40 | 2,578 | 797 | 783 | 4,158 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\BLAS | 5 | 836 | 53 | 167 | 1,056 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\STL | 2 | 193 | 50 | 45 | 288 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\blaze | 2 | 93 | 50 | 39 | 182 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\blitz | 5 | 307 | 127 | 105 | 539 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\eigen2 | 6 | 184 | 114 | 71 | 369 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\eigen3 | 6 | 240 | 120 | 82 | 442 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\gmm | 3 | 229 | 76 | 85 | 390 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\mtl4 | 3 | 211 | 94 | 80 | 385 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\tensors | 4 | 105 | 32 | 37 | 174 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\tvmet | 2 | 76 | 38 | 32 | 146 |
| Dependencies\\eigen-3.3.7\\bench\\btl\\libs\\ublas | 2 | 104 | 43 | 40 | 187 |
| Dependencies\\eigen-3.3.7\\bench\\perf_monitoring | 4 | 267 | 24 | 71 | 362 |
| Dependencies\\eigen-3.3.7\\bench\\perf_monitoring\\gemm | 4 | 267 | 24 | 71 | 362 |
| Dependencies\\eigen-3.3.7\\bench\\spbench | 6 | 756 | 126 | 106 | 988 |
| Dependencies\\eigen-3.3.7\\bench\\tensors | 8 | 919 | 101 | 148 | 1,168 |
| Dependencies\\eigen-3.3.7\\blas | 41 | 5,808 | 2,643 | 1,276 | 9,727 |
| Dependencies\\eigen-3.3.7\\blas\\f2c | 21 | 3,764 | 2,089 | 791 | 6,644 |
| Dependencies\\eigen-3.3.7\\blas\\testing | 1 | 40 | 1 | 5 | 46 |
| Dependencies\\eigen-3.3.7\\cmake | 31 | 5,694 | 0 | 792 | 6,486 |
| Dependencies\\eigen-3.3.7\\debug | 2 | 132 | 31 | 54 | 217 |
| Dependencies\\eigen-3.3.7\\debug\\gdb | 2 | 132 | 31 | 54 | 217 |
| Dependencies\\eigen-3.3.7\\demos | 15 | 1,734 | 230 | 391 | 2,355 |
| Dependencies\\eigen-3.3.7\\demos\\mandelbrot | 2 | 226 | 25 | 35 | 286 |
| Dependencies\\eigen-3.3.7\\demos\\mix_eigen_and_c | 3 | 215 | 43 | 65 | 323 |
| Dependencies\\eigen-3.3.7\\demos\\opengl | 10 | 1,293 | 162 | 291 | 1,746 |
| Dependencies\\eigen-3.3.7\\doc | 347 | 3,209 | 112 | 733 | 4,054 |
| Dependencies\\eigen-3.3.7\\doc\\examples | 68 | 1,232 | 48 | 279 | 1,559 |
| Dependencies\\eigen-3.3.7\\doc\\snippets | 272 | 1,455 | 17 | 331 | 1,803 |
| Dependencies\\eigen-3.3.7\\doc\\special_examples | 3 | 75 | 3 | 21 | 99 |
| Dependencies\\eigen-3.3.7\\failtest | 53 | 605 | 1 | 231 | 837 |
| Dependencies\\eigen-3.3.7\\lapack | 9 | 308 | 87 | 76 | 471 |
| Dependencies\\eigen-3.3.7\\scripts | 2 | 214 | 44 | 45 | 303 |
| Dependencies\\eigen-3.3.7\\test | 145 | 17,911 | 2,398 | 3,778 | 24,087 |
| Dependencies\\eigen-3.3.7\\unsupported | 266 | 54,985 | 10,397 | 11,210 | 76,592 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen | 153 | 35,130 | 8,186 | 7,121 | 50,437 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\CXX11 | 87 | 22,210 | 3,515 | 4,281 | 30,006 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\CXX11\\src | 87 | 22,210 | 3,515 | 4,281 | 30,006 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\CXX11\\src\\Tensor | 70 | 19,668 | 2,680 | 3,772 | 26,120 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\CXX11\\src\\TensorSymmetry | 4 | 967 | 408 | 165 | 1,540 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\CXX11\\src\\TensorSymmetry\\util | 1 | 371 | 250 | 49 | 670 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\CXX11\\src\\ThreadPool | 8 | 628 | 261 | 103 | 992 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\CXX11\\src\\util | 5 | 947 | 166 | 241 | 1,354 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src | 66 | 12,920 | 4,671 | 2,840 | 20,431 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\AutoDiff | 3 | 705 | 159 | 161 | 1,025 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\BVH | 2 | 359 | 78 | 81 | 518 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\Eigenvalues | 1 | 411 | 288 | 107 | 806 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\EulerAngles | 2 | 333 | 294 | 87 | 714 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\FFT | 2 | 550 | 51 | 82 | 683 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\IterativeSolvers | 7 | 1,009 | 529 | 231 | 1,769 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\KroneckerProduct | 1 | 166 | 101 | 39 | 306 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\LevenbergMarquardt | 5 | 640 | 234 | 161 | 1,035 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\MatrixFunctions | 6 | 1,703 | 590 | 300 | 2,593 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\MoreVectorization | 1 | 54 | 18 | 24 | 96 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\NonLinearOptimization | 11 | 1,476 | 320 | 362 | 2,158 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\NumericalDiff | 1 | 82 | 32 | 17 | 131 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\Polynomials | 3 | 486 | 232 | 110 | 828 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\Skyline | 6 | 1,422 | 268 | 385 | 2,075 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\SparseExtra | 6 | 1,668 | 519 | 273 | 2,460 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\SpecialFunctions | 6 | 1,292 | 652 | 257 | 2,201 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\SpecialFunctions\\arch | 1 | 127 | 11 | 28 | 166 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\SpecialFunctions\\arch\\CUDA | 1 | 127 | 11 | 28 | 166 |
| Dependencies\\eigen-3.3.7\\unsupported\\Eigen\\src\\Splines | 3 | 564 | 306 | 163 | 1,033 |
| Dependencies\\eigen-3.3.7\\unsupported\\bench | 1 | 80 | 16 | 28 | 124 |
| Dependencies\\eigen-3.3.7\\unsupported\\doc | 13 | 335 | 19 | 89 | 443 |
| Dependencies\\eigen-3.3.7\\unsupported\\doc\\examples | 13 | 335 | 19 | 89 | 443 |
| Dependencies\\eigen-3.3.7\\unsupported\\test | 99 | 19,440 | 2,176 | 3,972 | 25,588 |
| Dependencies\\eigen-3.3.7\\unsupported\\test\\mpreal | 1 | 2,296 | 283 | 526 | 3,105 |
| Dependencies\\sFoundation20 | 13 | 4,996 | 11,606 | 932 | 17,534 |
| Dependencies\\sFoundation20\\inc | 12 | 4,379 | 11,606 | 931 | 16,916 |
| Dependencies\\sFoundation20\\win32 | 1 | 617 | 0 | 1 | 618 |
| include | 8 | 201 | 72 | 48 | 321 |
| test | 1 | 23 | 1 | 2 | 26 |
| tools | 1 | 15,919 | 3,869 | 2,670 | 22,458 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)